@foreach($details as $key => $value)

<p> {{ $key }} : {{$value}} </p>

@endforeach
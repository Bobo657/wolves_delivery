<?php return array (
  'add-delivery' => 'App\\Http\\Livewire\\AddDelivery',
  'delivery' => 'App\\Http\\Livewire\\Delivery',
  'edit-delivery' => 'App\\Http\\Livewire\\EditDelivery',
);
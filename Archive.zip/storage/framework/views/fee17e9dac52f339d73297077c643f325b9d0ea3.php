<div class="layout-px-spacing">

    <div class="page-header">
        <div class="page-title">
            <h3> Delivery Dashboard 
                <button class="btn btn-primary mb-2 mr-2"  data-toggle="modal" data-target="#add-delivery">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-square">
                    <polyline points="9 11 12 14 22 4"></polyline>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>Add New Delivery
                </button>
            </h3>

        </div>


        <div class="form-group">
            <input type="text" class="form-control" wire:model="search" aria-describedby="h-text1" placeholder="Seach.....">
        </div>
    </div>

    <div class="row layout-spacing">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
            <div class="table-responsive">
                <table class="table mb-4">
                <caption>List of all deliveries</caption>
                <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Location</th>
                            <th class="">Status</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($delivery->tracking_number); ?></td>
                            <td class="text-primary"><?php echo e($delivery->sender); ?></td>
                            <td><?php echo e($delivery->email); ?></td>
                            <td><?php echo e($delivery->phone); ?></td>
                            <td><?php echo e($delivery->location); ?></td>
                            <td><?php echo e($delivery->destination); ?></td>
                            <td><?php echo e($delivery->current_location); ?></td>
                            <td class="">
                                <span class="shadow-none badge outline-badge-<?php echo e($delivery->status_color); ?>">
                                <?php echo e($delivery->status); ?>

                                </span>
                            </td>
                            <td><?php echo e($delivery->created_at->format('Y-m-d')); ?></td>
                            <td class="text-center">
                            <div class="dropdown d-inline-block">
                                    <a class="dropdown-toggle" href="#" role="button" id="pendingTask" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical">
                                            <circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle>
                                            <circle cx="12" cy="19" r="1"></circle>
                                        </svg>
                                    </a>

                                    <div class="dropdown-menu left" aria-labelledby="pendingTask" style="will-change: transform;">
                                        <a class="dropdown-item" href="javascript:void(0);" wire:click.prevent="changeStatus(<?php echo e($delivery->id); ?>, 'in transit')">
            
                                            In Transit
                                        </a>
                                        <a class="dropdown-item" href="javascript:void(0);" wire:click.prevent="changeStatus(<?php echo e($delivery->id); ?>, 'onhold')">
                                            Onhold
                                        </a>
                                        <a class="dropdown-item" href="javascript:void(0);" wire:click.prevent="changeStatus(<?php echo e($delivery->id); ?>, 'delivered')">
                                            Delivered
                                        </a>
                                        <a class="dropdown-item" href="javascript:void(0);" wire:click.prevent="$emitTo('edit-delivery', 'get_delivery', '<?php echo e($delivery->id); ?>')">
                                            Edit 
                                        </a>
                                        <a class="dropdown-item" href="javascript:void(0);" wire:click.prevent="delete(<?php echo e($delivery->id); ?>)">
                                            Delete
                                        </a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('edit-delivery')->html();
} elseif ($_instance->childHasBeenRendered('Nt2L5Ii')) {
    $componentId = $_instance->getRenderedChildComponentId('Nt2L5Ii');
    $componentTag = $_instance->getRenderedChildComponentTagName('Nt2L5Ii');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Nt2L5Ii');
} else {
    $response = \Livewire\Livewire::mount('edit-delivery');
    $html = $response->html();
    $_instance->logRenderedChild('Nt2L5Ii', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-delivery')->html();
} elseif ($_instance->childHasBeenRendered('K80EM66')) {
    $componentId = $_instance->getRenderedChildComponentId('K80EM66');
    $componentTag = $_instance->getRenderedChildComponentTagName('K80EM66');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K80EM66');
} else {
    $response = \Livewire\Livewire::mount('add-delivery');
    $html = $response->html();
    $_instance->logRenderedChild('K80EM66', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div><?php /**PATH /Users/cobbo/Documents/Projects/delivery/resources/views/livewire/delivery.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p> <?php echo e($key); ?> : <?php echo e($value); ?> </p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Users/cobbo/Documents/Projects/delivery/resources/views/contact_mail.blade.php ENDPATH**/ ?>
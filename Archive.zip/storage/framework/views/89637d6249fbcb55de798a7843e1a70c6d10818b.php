<a href="/">
    <img src="/assets/img/logo.png" class="navbar-logo" alt="logo">
</a>
<?php /**PATH /Users/cobbo/Documents/Projects/delivery/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>